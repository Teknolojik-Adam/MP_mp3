import sys
import librosa
import numpy as np
import joblib

model = joblib.load('music_genre_classifier.pkl')

def predict_genre(file_name):
    features = extract_features(file_name)
    features = features.reshape(1, -1)
    genre = model.predict(features)
    return genre[0]

def extract_features(file_name):
    y, sr = librosa.load(file_name, mono=True, duration=30)
    mfccs = np.mean(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40).T, axis=0)
    return mfccs

if __name__ == '__main__':
    file_name = sys.argv[1]
    print(predict_genre(file_name))